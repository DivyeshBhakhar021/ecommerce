module.exports.categoriesController = require("./categories.controller");
module.exports.subcategoriesController = require("./subcategories.controller");
module.exports.productCproductontroller= require("./product.controller")
